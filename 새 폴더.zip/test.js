 

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<script>


var input = prompt("몇 초 간격 ?", 10);
console.log(input);
input = parseInt(input);
setInterval(() => console.log(input--), input * 1000);










</script>

</body>
</html>