function refresh(){
      
       var input = 0 
       input = prompt("Input Time(Seconds)", 10);
       console.log("입력 값 : "+input);
       if(!input){
           alert('Input cannot be null');
    }
     if (input <= 0){
        window.location.reload()
        clearInterval(timer);

     }
     input = parseInt(input)-1;
     setInterval(console.log(input--+" seconds left"), 1000);
     
  }

chrome.extension.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.action === "START") { 
     refresh();
 }
});




/*시간 표시 기능 구현 */  
/*중지(정지) 및 설정 변경 기능 구현 */ 



