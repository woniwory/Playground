
document.getElementById("start").onclick = () {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {action: "START"}, /* callback */);
    });
};


/*시간 표시 기능 구현 */  
/*중지(정지) 및 설정 변경 기능 구현 */ 

